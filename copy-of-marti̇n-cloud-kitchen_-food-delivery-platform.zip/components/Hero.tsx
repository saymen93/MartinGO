
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="bg-white">
      <div className="container mx-auto px-6 py-16 md:py-24 flex flex-col md:flex-row items-center">
        <div className="md:w-1/2 lg:w-3/5 text-center md:text-left mb-12 md:mb-0">
          <h1 className="text-4xl md:text-6xl font-extrabold text-black leading-tight mb-4">
            Şehrin Lezzeti, <br/>
            <span className="text-red-600">Anında Kapında.</span>
          </h1>
          <p className="text-lg text-gray-600 max-w-xl mx-auto md:mx-0 mb-8">
            MARTİN Cloud Kitchen, en iyi yerel restoranları kapınıza getirir. Favori yemeklerinizi birkac dokunuşla sipariş edin, dakikalar içinde teslim alın.
          </p>
          <div className="flex justify-center md:justify-start space-x-4">
            <a href="#join" className="bg-red-600 text-white px-8 py-3 rounded-full font-semibold text-lg hover:bg-red-700 transition-transform transform hover:scale-105">
              Hemen Başla
            </a>
            <a href="#features" className="bg-gray-200 text-black px-8 py-3 rounded-full font-semibold text-lg hover:bg-gray-300 transition-transform transform hover:scale-105">
              Daha Fazlası
            </a>
          </div>
        </div>
        <div className="md:w-1/2 lg:w-2/5 flex justify-center">
          <div className="relative w-64 h-[520px] bg-black rounded-[40px] border-[10px] border-black shadow-2xl overflow-hidden">
            {/* Using a more food-app related placeholder image */}
            <img src="https://images.unsplash.com/photo-1576866209830-589e1bfd40d6?q=80&w=800" alt="App Screenshot" className="w-full h-full object-cover" />
            <div className="absolute top-0 left-0 w-full h-full bg-black bg-opacity-10"></div>
            <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-24 h-6 bg-black rounded-b-xl"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
