
import React from 'react';

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  features: string[];
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description, features }) => (
  <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-100 flex flex-col">
    <div className="flex items-center mb-4">
      <div className="bg-red-100 p-3 rounded-full mr-4 text-red-600">
        {icon}
      </div>
      <h3 className="text-2xl font-bold text-black">{title}</h3>
    </div>
    <p className="text-gray-600 mb-6 flex-grow">{description}</p>
    <ul className="space-y-3 text-gray-700">
      {features.map((feature, index) => (
        <li key={index} className="flex items-start">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          <span>{feature}</span>
        </li>
      ))}
    </ul>
  </div>
);

const Features: React.FC = () => {
  const customerFeatures = {
    icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" /></svg>,
    title: "Müşteriler İçin",
    description: "En iyi yerel restoranlara erişim ve gerçek zamanlı takip ile kusursuz bir yemek siparişi deneyiminin keyfini çıkarın.",
    features: ["Yakındaki Restoranları Keşfetme", "Canlı Sipariş & Kurye Takibi", "Güvenli 3DS Ödeme", "Alerjen Uyarıları ve Rozetleri"]
  };

  const restaurantFeatures = {
    icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h6m-6 4h6m-6 4h6" /></svg>,
    title: "Restoranlar İçin",
    description: "Güçlü iş ortağı panelimizle işinizi büyütün. Menüleri, siparişleri ve finansalları kolaylıkla yönetin.",
    features: ["Kolay Menü Yönetimi (Resim Yükleme)", "Gerçek Zamanlı Sipariş Paneli", "Kampanya ve Promosyon Araçları", "Detaylı Finans Raporları"]
  };

  const courierFeatures = {
    icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10l2-2h8z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10l2-2h8zm0 0l6 2v-4l-6-2z" /></svg>,
    title: "Kuryeler İçin",
    description: "Esnek ve verimli bir şekilde kazanın. Kurye uygulamamız akıllı rotalar ve net görev yönetimi sunar.",
    features: ["Esnek Görev Havuzu", "Optimize Edilmiş Teslimat Rotaları", "Teslimat Kanıtı Yükleme (Fotoğraf)", "Şeffaf Kazanç Özeti"]
  };
  
  return (
    <section id="features" className="py-20 bg-gray-100">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-extrabold text-black">Eksiksiz Bir Ekosistem</h2>
          <p className="text-lg text-gray-600 mt-2 max-w-2xl mx-auto">
            Yemek teslimat sürecindeki herkes için güçlü, entegre bir platform oluşturduk.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <FeatureCard {...customerFeatures} />
          <FeatureCard {...restaurantFeatures} />
          <FeatureCard {...courierFeatures} />
        </div>
      </div>
    </section>
  );
};

export default Features;
