
import React from 'react';

interface TechItemProps {
  name: string;
}

const TechItem: React.FC<TechItemProps> = ({ name }) => (
  <div className="bg-white px-6 py-3 rounded-lg shadow-md text-center text-gray-700 font-medium border border-gray-200 hover:border-red-500 hover:text-red-600 transition-all">
    {name}
  </div>
);

const TechStack: React.FC = () => {
  const technologies = [
    "Flutter", "Dart", "Riverpod", "NestJS", "FastAPI", "React", "Next.js", "TypeScript", "PostgreSQL", "Redis", "Docker", "Firebase", "Google Maps", "Stripe", "İyzico", "WebSockets", "GitHub Actions", "Fastlane"
  ];

  return (
    <section id="tech" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-extrabold text-black">Modern Teknoloji ile Geliştirildi</h2>
          <p className="text-lg text-gray-600 mt-2 max-w-2xl mx-auto">
            Platformumuz, en yeni teknolojiler kullanılarak ölçeklenebilirlik, güvenilirlik ve performans için tasarlanmıştır.
          </p>
        </div>
        <div className="flex flex-wrap justify-center gap-4">
          {technologies.map(tech => <TechItem key={tech} name={tech} />)}
        </div>
      </div>
    </section>
  );
};

export default TechStack;
