
import React from 'react';

const StepCard: React.FC<{ icon: React.ReactNode; title: string; description: string }> = ({ icon, title, description }) => (
    <div className="flex items-start space-x-4">
        <div className="flex-shrink-0 bg-red-100 text-red-600 p-3 rounded-full">
            {icon}
        </div>
        <div>
            <h4 className="font-bold text-lg text-black">{title}</h4>
            <p className="text-gray-600">{description}</p>
        </div>
    </div>
);


const MediaUploadFeature: React.FC = () => {
  return (
    <section id="media-upload" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-extrabold text-black">Güvenli ve Modern Medya Altyapısı</h2>
          <p className="text-lg text-gray-600 mt-2 max-w-3xl mx-auto">
            Menü görsellerinden teslimat kanıtlarına kadar tüm medya yüklemeleri, hız ve güvenlik için tasarlanmış sağlam bir altyapı üzerinden yönetilir.
          </p>
        </div>

        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-10">
            <StepCard 
                icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" /></svg>}
                title="1. Güvenli Yükleme İsteği"
                description="Mobil uygulama, dosya boyutu ve tipi gibi bilgilerle sunucudan güvenli bir yükleme adresi (Pre-signed URL) talep eder."
            />
            <StepCard 
                icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>}
                title="2. Doğrudan Buluta Yükleme"
                description="Cihaz, dosyayı doğrudan ve şifreli olarak bulut depolama (S3) alanına yükler. Bu, sunucu yükünü azaltır ve hızı artırır."
            />
            <StepCard 
                icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
                title="3. Doğrulama ve İşleme"
                description="Yükleme tamamlandığında, sunucumuz dosyayı doğrular, virüs taramasından geçirir ve farklı boyutlarda (thumbnail vb.) işler."
            />
            <StepCard 
                icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" /></svg>}
                title="4. CDN ile Hızlı Dağıtım"
                description="Onaylanan görseller, dünya geneline yayılmış CDN (Content Delivery Network) üzerinden kullanıcılara anında ve optimize bir şekilde sunulur."
            />
        </div>
      </div>
    </section>
  );
};

export default MediaUploadFeature;
