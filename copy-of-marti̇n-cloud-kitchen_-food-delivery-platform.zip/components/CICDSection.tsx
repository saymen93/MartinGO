import React from 'react';

// Reusable card for each step in the CI/CD pipeline
const PipelineStep: React.FC<{ icon: React.ReactNode; title: string; description: string }> = ({ icon, title, description }) => (
    <div className="flex flex-col items-center text-center p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-100 h-full">
        <div className="flex-shrink-0 bg-red-100 text-red-600 p-4 rounded-full mb-4">
            {icon}
        </div>
        <div>
            <h4 className="font-bold text-lg text-black mb-2">{title}</h4>
            <p className="text-gray-600 text-sm">{description}</p>
        </div>
    </div>
);

// Main component for the CI/CD section
const CICDSection: React.FC = () => {
  return (
    <section id="cicd" className="py-20 bg-gray-100">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-extrabold text-black">Otomatik ve Güvenilir Dağıtım</h2>
          <p className="text-lg text-gray-600 mt-2 max-w-3xl mx-auto">
            Fastlane ve CI/CD otomasyonu sayesinde, yeni özellikleri ve güncellemeleri App Store ve Google Play'e hızlı ve hatasız bir şekilde ulaştırıyoruz.
          </p>
        </div>

        <div className="relative max-w-5xl mx-auto">
            <div className="hidden lg:block absolute top-1/2 -translate-y-1/2 left-0 right-0 h-1 bg-red-200"></div>
            <div className="relative grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <PipelineStep
                    icon={
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" /></svg>
                    }
                    title="1. Kodu Gönder"
                    description="Geliştiriciler kodu GitHub'a gönderdiğinde, CI/CD süreci otomatik olarak tetiklenir."
                />
                <PipelineStep
                    icon={
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                    }
                    title="2. Test ve İnşa Et"
                    description="GitHub Actions, kodu derler ve otomatik testleri (unit, widget) çalıştırarak kaliteyi garanti altına alır."
                />
                <PipelineStep
                    icon={
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" /></svg>
                    }
                    title="3. Fastlane ile Otomatikleştir"
                    description="Fastlane, uygulama sürümünü artırır, metadata'yı günceller ve mağaza için gerekli paketleri (.ipa/.aab) oluşturur."
                />
                <PipelineStep
                    icon={
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
                    }
                    title="4. Mağazalara Yükle"
                    description="Oluşturulan paketler, TestFlight ve Google Play Console'a otomatik olarak yüklenir ve test ekiplerine sunulur."
                />
            </div>
        </div>
      </div>
    </section>
  );
};

export default CICDSection;