
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-200">
      <div className="container mx-auto px-6 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center text-center md:text-left">
          <div className="text-2xl font-bold mb-4 md:mb-0">
            <span className="text-red-600">M</span>
            <span className="text-black">ARTİN</span>
          </div>
          <div className="flex flex-wrap justify-center space-x-6 text-gray-700 mb-4 md:mb-0">
            <a href="#" className="hover:text-red-600">Hakkımızda</a>
            <a href="#" className="hover:text-red-600">Kariyer</a>
            <a href="#" className="hover:text-red-600">İletişim</a>
            <a href="#" className="hover:text-red-600">Gizlilik Politikası</a>
          </div>
          <p className="text-gray-600 text-sm">
            © {new Date().getFullYear()} MARTİN Cloud Kitchen. Tüm hakları saklıdır.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
