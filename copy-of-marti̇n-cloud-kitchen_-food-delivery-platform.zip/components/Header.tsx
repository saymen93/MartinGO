
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <div className="text-3xl font-bold">
          <span className="text-red-600">M</span>
          <span className="text-black">ARTİN</span>
        </div>
        <nav className="hidden md:flex space-x-8 items-center">
          <a href="#features" className="text-gray-600 hover:text-red-600 transition-colors">Özellikler</a>
          <a href="#tech" className="text-gray-600 hover:text-red-600 transition-colors">Teknoloji</a>
          <a href="#join" className="bg-black text-white px-4 py-2 rounded-full hover:bg-gray-800 transition-colors">
            Uygulamayı İndir
          </a>
        </nav>
        <button className="md:hidden text-black">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
          </svg>
        </button>
      </div>
    </header>
  );
};

export default Header;
