
import React from 'react';

const CTASection: React.FC = () => {
  return (
    <section id="join" className="bg-black text-white py-20">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-4xl font-extrabold mb-4">MARTİN Ailesine Katılın</h2>
        <p className="text-lg text-gray-300 max-w-2xl mx-auto mb-8">
          İster acıkmış olun, ister bir restoran sahibi olun ya da bizimle birlikte yola çıkmak isteyin, MARTİN'de size de yer var.
        </p>
        <div className="flex flex-col md:flex-row justify-center items-center space-y-4 md:space-y-0 md:space-x-4">
          <a href="#" className="bg-red-600 text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-red-700 transition-transform transform hover:scale-105 inline-block w-full md:w-auto">
            Uygulamayı İndir
          </a>
          <a href="#" className="bg-gray-800 text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-gray-700 transition-transform transform hover:scale-105 inline-block w-full md:w-auto">
            İş Ortağı Ol
          </a>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
