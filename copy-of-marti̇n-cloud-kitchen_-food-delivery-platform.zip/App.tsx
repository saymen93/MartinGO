import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import TechStack from './components/TechStack';
import CTASection from './components/CTASection';
import Footer from './components/Footer';
import MediaUploadFeature from './components/MediaUploadFeature';
import CICDSection from './components/CICDSection';

function App() {
  return (
    <div className="bg-gray-50 min-h-screen text-gray-800 font-sans">
      <Header />
      <main>
        <Hero />
        <Features />
        <MediaUploadFeature />
        <TechStack />
        <CICDSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}

export default App;